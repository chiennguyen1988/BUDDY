/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Play, RotateCcw, Check, Clock, Trophy, HelpCircle, Award, Star, Flame, Sparkles, Volume2, VolumeX } from 'lucide-react';

// Word puzzle structures
interface WordBlock {
  startIndex: number;
  length: number;
}

interface QuestionRow {
  id: number;
  question: string;
  answerText: string;
  chars: string[];
  hintIndices: number[];
  blocks: WordBlock[];
}

const QUESTIONS: QuestionRow[] = [
  {
    id: 1,
    question: "Một chương trình Buddy thành công không được đo bằng số buổi gặp gỡ, mà bằng điều gì được tạo ra giữa các đồng đội?",
    answerText: "GAN KET",
    chars: ['G', 'A', 'N', 'K', 'E', 'T'],
    hintIndices: [0, 3], // G, K
    blocks: [
      { startIndex: 0, length: 3 }, // GAN
      { startIndex: 3, length: 3 }  // KET
    ]
  },
  {
    id: 2,
    question: "Người hỗ trợ nhân viên mới trong chương trình?",
    answerText: "BUDDY",
    chars: ['B', 'U', 'D', 'D', 'Y'],
    hintIndices: [0, 2], // B, D
    blocks: [
      { startIndex: 0, length: 5 } // BUDDY
    ]
  },
  {
    id: 3,
    question: "Không cần nói quá nhiều nhưng vẫn hiểu đồng đội đang cần gì. Tên của kỹ năng tạo nên sự kết nối đó là gì?",
    answerText: "THAU HIEU",
    chars: ['T', 'H', 'A', 'U', 'H', 'I', 'E', 'U'],
    hintIndices: [0, 4], // T, H
    blocks: [
      { startIndex: 0, length: 4 }, // THAU
      { startIndex: 4, length: 4 }  // HIEU
    ]
  },
  {
    id: 4,
    question: "Một đồng đội tốt không đi thay bạn — họ ở cạnh để bạn tự tin bước tiếp. Đó là hành động gì?",
    answerText: "HO TRO",
    chars: ['H', 'O', 'T', 'R', 'O'],
    hintIndices: [0, 2], // H, T
    blocks: [
      { startIndex: 0, length: 2 }, // HO
      { startIndex: 2, length: 3 }  // TRO
    ]
  },
  {
    id: 5,
    question: "Điều gì càng cho đi càng lan tỏa, biến tập thể thành nơi mọi người muốn gắn bó?",
    answerText: "CHIA SE",
    chars: ['C', 'H', 'I', 'A', 'S', 'E'],
    hintIndices: [0, 3, 4], // C, A, S ("C _ _ A S _")
    blocks: [
      { startIndex: 0, length: 4 }, // CHIA
      { startIndex: 4, length: 2 }  // SE
    ]
  }
];

// High fidelity VPS logo SVG component
const VPSLogo = ({ size = "h-8" }: { size?: string }) => (
  <div className="flex items-center gap-1.5 select-none shrink-0">
    <span className="text-2xl font-black tracking-tight text-slate-800 font-sans leading-none translate-y-[-1px]">vps</span>
    <svg className={`${size} w-auto`} viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Outer curve of logo */}
      <path d="M10 6H24C27.3137 6 30 8.68629 30 12V24C30 24 27.5 24 27.5 24V14C27.5 10.6863 24.8137 8 21.5 8H10C10 8 10 6 10 6Z" fill="#7C3AED" />
      {/* Inner curve of logo */}
      <path d="M10 15H18C19.6569 15 21 16.3431 21 18V24C21 24 19 24 19 24V19C19 18.1716 17.8284 17 16.5 17H10C10 17 10 15 10 15ZM10 21C10 21 15 21 15 21C15 21 15 22.5 15 22.5C15 22.5 10 22.5 10 22.5" fill="#7C3AED" />
    </svg>
  </div>
);

// Decorative city financial skyline illustration inspired by VPS dashboard screenshot
const CityDashboardBackdrop = () => (
  <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
    {/* Subtle gradient nodes representing stock values */}
    <svg className="absolute bottom-0 left-0 w-full h-[65vh] opacity-25" viewBox="0 0 400 300" preserveAspectRatio="none" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Abstract city bars matching the light violet/pink style */}
      <g fill="#A78BFA" opacity="0.18">
        <rect x="10" y="160" width="12" height="140" rx="2" />
        <rect x="26" y="190" width="10" height="110" rx="2" />
        <rect x="40" y="210" width="8" height="90" rx="1.5" />
        <rect x="52" y="130" width="14" height="170" rx="3" />
        <rect x="70" y="200" width="10" height="100" rx="2" />
        <rect x="84" y="220" width="12" height="80" rx="2" />
        <rect x="100" y="170" width="16" height="130" rx="3" />
        <rect x="120" y="230" width="10" height="70" rx="1.5" />
        <rect x="134" y="195" width="14" height="105" rx="2.5" />
        <rect x="152" y="225" width="12" height="75" rx="2" />
        <rect x="168" y="205" width="10" height="95" rx="2" />
        <rect x="182" y="240" width="8" height="60" rx="1" />
        <rect x="194" y="180" width="15" height="120" rx="3" />
        
        {/* Right pinkish city gradients */}
        <rect x="214" y="190" width="10" height="110" rx="2" fill="#F472B6" opacity="0.4" />
        <rect x="228" y="210" width="12" height="90" rx="2" fill="#F472B6" opacity="0.4" />
        <rect x="244" y="230" width="8" height="70" rx="1.5" fill="#F472B6" opacity="0.4" />
        <rect x="256" y="200" width="14" height="100" rx="2.5" fill="#F472B6" opacity="0.4" />
        <rect x="274" y="245" width="10" height="55" rx="1.5" fill="#F472B6" opacity="0.4" />
        <rect x="288" y="215" width="12" height="85" rx="2" fill="#F472B6" opacity="0.4" />
        <rect x="304" y="175" width="16" height="125" rx="3" fill="#F472B6" opacity="0.4" />
        <rect x="324" y="235" width="12" height="65" rx="2" fill="#F472B6" opacity="0.4" />
        <rect x="340" y="205" width="10" height="95" rx="2" fill="#F472B6" opacity="0.4" />
        <rect x="354" y="220" width="14" height="80" rx="2.5" fill="#F472B6" opacity="0.4" />
        <rect x="372" y="250" width="12" height="50" rx="2" fill="#F472B6" opacity="0.4" />
        <rect x="388" y="210" width="10" height="90" rx="2" fill="#F472B6" opacity="0.4" />
      </g>
      
      {/* Decorative growth stock lines */}
      <path d="M-10 260 L80 180 L140 210 L210 140 L280 190 L340 120 L410 150" stroke="#7C3AED" strokeWidth="2.5" strokeLinecap="round" opacity="0.3" />
      <path d="M-10 260 L80 180 L140 210 L210 140 L280 190 L340 120 L410 150" stroke="#F472B6" strokeWidth="1.2" strokeLinecap="round" opacity="0.4" />
      
      {/* Node rings */}
      <circle cx="80" cy="180" r="4.5" fill="#FFFFFF" stroke="#7C3AED" strokeWidth="2" opacity="0.8" />
      <circle cx="140" cy="210" r="4.5" fill="#FFFFFF" stroke="#7C3AED" strokeWidth="2" opacity="0.8" />
      <circle cx="210" cy="140" r="4.5" fill="#FFFFFF" stroke="#7C3AED" strokeWidth="2" opacity="0.8" />
      <circle cx="280" cy="190" r="4.5" fill="#FFFFFF" stroke="#7C3AED" strokeWidth="2" opacity="0.8" />
      <circle cx="340" cy="120" r="4.5" fill="#FFFFFF" stroke="#F472B6" strokeWidth="2" opacity="0.8" />
    </svg>
  </div>
);

export default function App() {
  const [gameState, setGameState] = useState<'IDLE' | 'PLAYING' | 'WON'>('IDLE');
  const [timer, setTimer] = useState<number>(0);
  const [score, setScore] = useState<number>(0);
  const [bestTime, setBestTime] = useState<number | null>(null);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  
  // User answers state: array of 5 arrays, tracking characters typed
  const [userAnswers, setUserAnswers] = useState<string[][]>([]);
  const [completedRows, setCompletedRows] = useState<boolean[]>([]);
  const [shakingRows, setShakingRows] = useState<boolean[]>([]);
  
  const [activeRowIndex, setActiveRowIndex] = useState<number>(0);
  const [activeCellIndex, setActiveCellIndex] = useState<number>(1); // default active index
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' | 'info' | null }>({ text: '', type: null });

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Initialize bestTime from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('vps_buddy_best_time');
    if (saved) {
      setBestTime(parseInt(saved, 10));
    }
  }, []);

  // Set up game parameters on game start
  const handleStartGame = () => {
    // Reset answers with initial hints prefilled
    const initialAnswers = QUESTIONS.map(q => {
      const arr = Array(q.chars.length).fill('');
      q.hintIndices.forEach(idx => {
        arr[idx] = q.chars[idx];
      });
      return arr;
    });

    setUserAnswers(initialAnswers);
    setCompletedRows(Array(5).fill(false));
    setShakingRows(Array(5).fill(false));
    setActiveRowIndex(0);
    
    // Set first interactive cell in Row 0
    const firstFreeIndex = QUESTIONS[0].hintIndices.includes(0) 
      ? QUESTIONS[0].hintIndices.includes(1) ? 2 : 1 
      : 0;
    setActiveCellIndex(firstFreeIndex);
    
    setTimer(0);
    setScore(0);
    setGameState('PLAYING');
    setMessage({ text: 'Chào mừng bạn đến với Buddy Challenge! Hãy chinh phục 5 hàng ô chữ.', type: 'info' });
    playSound('win'); // cheerful chime
  };

  // Timer Effect
  useEffect(() => {
    if (gameState === 'PLAYING') {
      timerRef.current = setInterval(() => {
        setTimer(prev => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [gameState]);

  // Audio synthesis helper to avoid missing asset errors
  const playSound = (type: 'tap' | 'success' | 'fail' | 'win') => {
    if (!soundEnabled) return;
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      if (type === 'tap') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(600, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(180, ctx.currentTime + 0.08);
        gain.gain.setValueAtTime(0.04, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
        osc.start();
        osc.stop(ctx.currentTime + 0.09);
      } else if (type === 'success') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
        osc.frequency.setValueAtTime(659.25, ctx.currentTime + 0.08); // E5
        osc.frequency.setValueAtTime(783.99, ctx.currentTime + 0.16); // G5
        gain.gain.setValueAtTime(0.06, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
        osc.start();
        osc.stop(ctx.currentTime + 0.38);
      } else if (type === 'fail') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(140, ctx.currentTime);
        osc.frequency.linearRampToValueAtTime(95, ctx.currentTime + 0.22);
        gain.gain.setValueAtTime(0.05, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.24);
        osc.start();
        osc.stop(ctx.currentTime + 0.25);
      } else if (type === 'win') {
        const playTone = (freq: number, start: number, duration: number, soundType: 'sine' | 'triangle' = 'sine') => {
          const o = ctx.createOscillator();
          const g = ctx.createGain();
          o.type = soundType;
          o.frequency.setValueAtTime(freq, ctx.currentTime + start);
          g.gain.setValueAtTime(0.05, ctx.currentTime + start);
          g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + start + duration);
          o.connect(g);
          g.connect(ctx.destination);
          o.start(ctx.currentTime + start);
          o.stop(ctx.currentTime + start + duration);
        };
        // Elegant finish sequence
        playTone(392.00, 0, 0.12); // G4
        playTone(523.25, 0.08, 0.12); // C5
        playTone(659.25, 0.16, 0.12); // E5
        playTone(783.99, 0.24, 0.2); // G5
        playTone(1046.50, 0.36, 0.45, 'triangle'); // C6
      }
    } catch (e) {
      // Audio muted by browser restrictions before focus
    }
  };

  // Clean Vietnamese text to match simple capital characters
  const cleanAndNormalizeText = (char: string): string => {
    if (!char) return '';
    return char
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/đ/g, 'd')
      .replace(/Đ/g, 'd')
      .toUpperCase()
      .replace(/[^A-Z]/g, '');
  };

  // Custom glorious victory confetti
  useEffect(() => {
    if (gameState !== 'WON' || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || window.innerWidth);
    let height = (canvas.height = canvas.parentElement?.clientHeight || window.innerHeight);

    const handleResize = () => {
      width = canvas.width = canvas.parentElement?.clientWidth || window.innerWidth;
      height = canvas.height = canvas.parentElement?.clientHeight || window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    // Warm colors based on the clean red, violet, light gold and peach palette
    const colors = ['#7C3AED', '#EC4899', '#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];
    const particles = Array.from({ length: 110 }, () => ({
      x: Math.random() * width,
      y: Math.random() * height - height,
      size: Math.random() * 7 + 4,
      color: colors[Math.floor(Math.random() * colors.length)],
      speed: Math.random() * 2.5 + 2,
      rotation: Math.random() * 360,
      rotationSpeed: Math.random() * 3 - 1.5,
      wobble: Math.random() * 15,
      wobbleSpeed: Math.random() * 0.04 + 0.01
    }));

    const render = () => {
      ctx.clearRect(0, 0, width, height);
      particles.forEach(p => {
        p.y += p.speed;
        p.rotation += p.rotationSpeed;
        p.wobble += p.wobbleSpeed;
        
        ctx.save();
        ctx.translate(p.x + Math.sin(p.wobble) * 6, p.y);
        ctx.rotate((p.rotation * Math.PI) / 180);
        ctx.fillStyle = p.color;
        
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
        ctx.restore();
        
        if (p.y > height) {
          p.y = -15;
          p.x = Math.random() * width;
        }
      });
      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, [gameState]);

  // Handle typing from keyboard
  const handleKeyInput = (char: string) => {
    if (gameState !== 'PLAYING') return;

    const normalized = cleanAndNormalizeText(char);
    if (!normalized || normalized.length !== 1) return;

    playSound('tap');
    
    const nextAnswers = [...userAnswers];
    const currentRowAnswers = [...nextAnswers[activeRowIndex]];
    
    // Set cell value
    currentRowAnswers[activeCellIndex] = normalized;
    nextAnswers[activeRowIndex] = currentRowAnswers;
    setUserAnswers(nextAnswers);

    // Find next non-hint cell in this row to transition selection
    const row = QUESTIONS[activeRowIndex];
    let nextIndex = activeCellIndex + 1;
    let foundNext = false;

    while (nextIndex < row.chars.length) {
      if (!row.hintIndices.includes(nextIndex)) {
        setActiveCellIndex(nextIndex);
        foundNext = true;
        break;
      }
      nextIndex++;
    }

    if (!foundNext) {
      // Loop to any empty cell in active row
      const firstEmptyIndex = currentRowAnswers.findIndex((char, idx) => char === '' && !row.hintIndices.includes(idx));
      if (firstEmptyIndex !== -1) {
        setActiveCellIndex(firstEmptyIndex);
      }
    }
  };

  const handleBackspace = () => {
    if (gameState !== 'PLAYING') return;
    playSound('tap');

    const nextAnswers = [...userAnswers];
    const currentRowAnswers = [...nextAnswers[activeRowIndex]];
    const row = QUESTIONS[activeRowIndex];

    if (!row.hintIndices.includes(activeCellIndex)) {
      currentRowAnswers[activeCellIndex] = '';
    }

    // Shift selector leftward to last editable element
    let prevIndex = activeCellIndex - 1;
    let foundPrev = false;

    while (prevIndex >= 0) {
      if (!row.hintIndices.includes(prevIndex)) {
        setActiveCellIndex(prevIndex);
        foundPrev = true;
        break;
      }
      prevIndex--;
    }

    nextAnswers[activeRowIndex] = currentRowAnswers;
    setUserAnswers(nextAnswers);
  };

  // Keyboard hooks
  useEffect(() => {
    const handlePhysicalKeyDown = (e: KeyboardEvent) => {
      if (gameState !== 'PLAYING') return;
      if (e.repeat) return;

      const key = e.key;

      if (key === 'Backspace' || key === 'Delete') {
        e.preventDefault();
        handleBackspace();
      } else if (key === 'Enter') {
        e.preventDefault();
        handleCheckRowAnswers();
      } else if (key === 'ArrowLeft') {
        e.preventDefault();
        let prevIndex = activeCellIndex - 1;
        while (prevIndex >= 0) {
          if (!QUESTIONS[activeRowIndex].hintIndices.includes(prevIndex)) {
            setActiveCellIndex(prevIndex);
            break;
          }
          prevIndex--;
        }
      } else if (key === 'ArrowRight') {
        e.preventDefault();
        let nextIndex = activeCellIndex + 1;
        while (nextIndex < QUESTIONS[activeRowIndex].chars.length) {
          if (!QUESTIONS[activeRowIndex].hintIndices.includes(nextIndex)) {
            setActiveCellIndex(nextIndex);
            break;
          }
          nextIndex++;
        }
      } else if (key === 'ArrowUp') {
        e.preventDefault();
        if (activeRowIndex > 0) {
          selectRow(activeRowIndex - 1);
        }
      } else if (key === 'ArrowDown') {
        e.preventDefault();
        if (activeRowIndex < 4) {
          selectRow(activeRowIndex + 1);
        }
      } else {
        const cleaned = cleanAndNormalizeText(key);
        if (cleaned && cleaned.length === 1) {
          handleKeyInput(cleaned);
        }
      }
    };

    window.addEventListener('keydown', handlePhysicalKeyDown);
    return () => window.removeEventListener('keydown', handlePhysicalKeyDown);
  }, [gameState, activeRowIndex, activeCellIndex, userAnswers]);

  const selectRow = (rowIndex: number) => {
    if (gameState !== 'PLAYING') return;
    setActiveRowIndex(rowIndex);
    
    const row = QUESTIONS[rowIndex];
    let defaultIndex = 0;
    while (row.hintIndices.includes(defaultIndex) && defaultIndex < row.chars.length) {
      defaultIndex++;
    }
    setActiveCellIndex(defaultIndex < row.chars.length ? defaultIndex : 0);
    setMessage({ text: `Đang trả lời hàng số ${rowIndex + 1}.`, type: 'info' });
  };

  const handleCheckRowAnswers = () => {
    if (gameState !== 'PLAYING') return;

    let hasErrors = false;
    let newlyCorrectCount = 0;
    const nextCompletedRows = [...completedRows];
    const nextShakingRows = [...shakingRows];

    const row = QUESTIONS[activeRowIndex];
    const userRowAnswer = userAnswers[activeRowIndex].join('');
    const correctRowAnswer = row.chars.join('');

    if (userRowAnswer === correctRowAnswer) {
      if (!nextCompletedRows[activeRowIndex]) {
        nextCompletedRows[activeRowIndex] = true;
        newlyCorrectCount++;
        playSound('success');
      }
    } else {
      nextShakingRows[activeRowIndex] = true;
      hasErrors = true;
      playSound('fail');
      try {
        if ('vibrate' in navigator) navigator.vibrate(120);
      } catch (e) {}

      // Stop shake animation after delay
      setTimeout(() => {
        setShakingRows(prev => {
          const reset = [...prev];
          reset[activeRowIndex] = false;
          return reset;
        });
      }, 500);
    }

    setCompletedRows(nextCompletedRows);
    setShakingRows(nextShakingRows);

    if (hasErrors) {
      setMessage({ text: 'Có chữ cái chưa đúng ở hàng này, hãy kiểm tra kỹ nhé!', type: 'error' });
    } else {
      const basePoints = 100;
      const calculatedScore = nextCompletedRows.reduce((acc, current, idx) => {
        if (current) {
          const timeBonus = Math.max(0, 50 - Math.floor(timer / 6));
          return acc + basePoints + timeBonus;
        }
        return acc;
      }, 0);
      setScore(calculatedScore);

      const allCompleted = nextCompletedRows.every(status => status === true);
      if (allCompleted) {
        setGameState('WON');
        playSound('win');
        setMessage({ text: 'CHÚC MỪNG! Bạn đã trả lời đúng tất cả các câu hỏi.', type: 'success' });
        
        if (bestTime === null || timer < bestTime) {
          localStorage.setItem('vps_buddy_best_time', timer.toString());
          setBestTime(timer);
        }
      } else {
        setMessage({ text: 'Rất chính xác! Cùng giải các hàng còn lại nào.', type: 'success' });
        
        // Find next incomplete row
        const nextIncompleteIdx = nextCompletedRows.findIndex(status => !status);
        if (nextIncompleteIdx !== -1) {
          setTimeout(() => {
            selectRow(nextIncompleteIdx);
          }, 700);
        }
      }
    }
  };

  const formatTime = (totalSeconds: number): string => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const KEYBOARD_LAYOUT = [
    ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
    ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'],
    ['Backspace', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', 'Check']
  ];

  const finishedProgressPercentage = Math.round(
    (completedRows.filter(Boolean).length / QUESTIONS.length) * 100
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50/70 via-purple-50/50 to-pink-50/80 text-slate-800 flex flex-col justify-between overflow-x-hidden font-sans antialiased relative">
      
      {/* Absolute Decorative Stock Market / Silhouette backdrop */}
      <CityDashboardBackdrop />

      {/* Styled Animations CSS */}
      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          15%, 45%, 75% { transform: translateX(-6px); }
          30%, 60%, 90% { transform: translateX(6px); }
        }
        .animate-shake {
          animation: shake 0.45s ease-in-out;
        }
        @keyframes subtle-scale {
          0%, 100% { transform: scale(1.02); }
          50% { transform: scale(1.07); }
        }
        .animate-cell-pulse {
          animation: subtle-scale 0.9s infinite ease-in-out;
        }
        /* Custom scrollbar reset */
        .scrollbar-none::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-none {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>

      {/* Header Bar */}
      <header className="bg-white/75 backdrop-blur-md border-b border-purple-100 sticky top-0 z-40 px-4 py-3 shrink-0 shadow-[0_2px_12px_rgba(124,58,237,0.03)]">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <VPSLogo />
            <div className="w-[1px] h-6 bg-slate-200 mx-1" />
            <div>
              <h1 className="text-xs font-black tracking-wider text-purple-700">BUDDY WORK</h1>
              <p className="text-[9px] font-bold text-slate-500 tracking-wider mt-[-2px]">WORD CHALLENGE</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Audio Toggle */}
            <button
              id="sound_toggle_btn"
              onClick={() => { setSoundEnabled(!soundEnabled); playSound('tap'); }}
              className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors active:scale-95 border border-slate-200/50"
              title={soundEnabled ? "Tắt âm" : "Bật âm"}
            >
              {soundEnabled ? <Volume2 size={15} /> : <VolumeX size={15} />}
            </button>

            {/* Restart Button */}
            <button
              id="header_restart_btn"
              onClick={() => { handleStartGame(); }}
              className="px-2.5 py-1.5 rounded-lg bg-purple-50 border border-purple-100 text-[11px] font-bold text-purple-700 flex items-center gap-1 hover:bg-purple-100 transition-all active:scale-95"
            >
              <RotateCcw size={12} />
              <span>Chơi lại</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 w-full max-w-md mx-auto px-4 py-3 flex flex-col justify-start gap-3.5 z-10 relative">
        
        {/* Game IDLE Screen */}
        {gameState === 'IDLE' && (
          <div id="screen_idle" className="flex-1 flex flex-col justify-center items-center py-6 text-center">
            
            {/* Elegant VPS themed hero illustration */}
            <div className="relative mb-6">
              <div className="absolute inset-0 bg-purple-300/20 blur-2xl rounded-full scale-120 animate-pulse" />
              <div className="w-20 h-20 bg-gradient-to-tr from-purple-600 to-indigo-500 rounded-2xl flex items-center justify-center border border-white/40 text-white shadow-lg relative">
                <Award size={48} className="stroke-[1.5]" />
              </div>
            </div>
            
            <h2 className="text-2xl font-black tracking-tight text-slate-800 mb-2 uppercase">
              BUDDY CHALLENGE
            </h2>
            <p className="text-slate-600 text-[13px] max-w-xs px-2 mb-6 leading-relaxed">
              Vượt qua câu hỏi hàng ngang, ghi điểm số kỷ lục cùng <strong className="text-purple-600 font-bold">VPS Buddy</strong>. Chữ gợi ý sẽ đồng hành hỗ trợ bạn!
            </p>

            {/* Best Time Display Card */}
            {bestTime !== null && (
              <div className="w-full max-w-xs bg-white/80 border border-purple-100/80 rounded-2xl p-4.5 mb-7 flex items-center justify-between shadow-[0_4px_16px_rgba(124,58,237,0.05)]">
                <span className="text-xs font-semibold text-slate-500 flex items-center gap-2">
                  <Trophy size={15} className="text-yellow-500 shrink-0" />
                  Kỷ lục của bạn:
                </span>
                <span className="text-sm font-extrabold text-purple-700 font-mono bg-purple-50 px-2.5 py-1 rounded-lg">
                  {formatTime(bestTime)}
                </span>
              </div>
            )}

            <button
              id="start_game_launch_btn"
              onClick={handleStartGame}
              className="w-full max-w-xs bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-4 rounded-2xl font-extrabold tracking-wider flex items-center justify-center gap-2 shadow-[0_6px_20px_rgba(124,58,237,0.3)] hover:from-purple-500 hover:to-indigo-500 hover:shadow-purple-200/50 active:scale-[0.98] transition-all"
            >
              <Play fill="currentColor" size={16} />
              <span>BẮT ĐẦU CHƠI NGAY</span>
            </button>
          </div>
        )}

        {/* Active Playing View */}
        {gameState === 'PLAYING' && (
          <div id="screen_playing" className="flex-grow flex flex-col justify-start gap-3.5">
            
            {/* HUD Status Grid */}
            <div className="grid grid-cols-3 gap-2.5 shrink-0">
              
              {/* Score widget */}
              <div className="bg-white/90 border border-purple-100/65 rounded-2xl p-2.5 text-center flex flex-col justify-center shadow-xs">
                <div className="text-[9px] font-black text-slate-500 uppercase tracking-wider flex items-center justify-center gap-1">
                  <Star size={11} className="text-amber-500 fill-current" />
                  Điểm số
                </div>
                <div className="text-base font-black text-slate-900 font-mono mt-0.5">{score}</div>
              </div>

              {/* Time elapsed widget */}
              <div className="bg-white/90 border border-purple-100/65 rounded-2xl p-2.5 text-center flex flex-col justify-center shadow-xs">
                <div className="text-[9px] font-black text-slate-500 uppercase tracking-wider flex items-center justify-center gap-1">
                  <Clock size={11} className="text-purple-600" />
                  Thời gian
                </div>
                <div className="text-base font-black text-purple-700 font-mono mt-0.5">{formatTime(timer)}</div>
              </div>

              {/* Best time widget */}
              <div className="bg-white/90 border border-purple-100/65 rounded-2xl p-2.5 text-center flex flex-col justify-center shadow-xs">
                <div className="text-[9px] font-black text-slate-500 uppercase tracking-wider flex items-center justify-center gap-1.5">
                  <Trophy size={11} className="text-yellow-600" />
                  Kỷ lục
                </div>
                <div className="text-base font-black text-yellow-600 font-mono mt-0.5">
                  {bestTime ? formatTime(bestTime) : "--:--"}
                </div>
              </div>
            </div>

            {/* Completion Progress Bar */}
            <div className="bg-white/80 border border-purple-100/50 rounded-2xl p-2.5 shrink-0 shadow-xs">
              <div className="flex justify-between items-center mb-1.5 text-[10px] text-slate-500 font-extrabold uppercase tracking-widest">
                <span className="flex items-center gap-1"><Flame size={12} className="text-orange-500" /> Tiến độ chơi</span>
                <span>{finishedProgressPercentage}% ({completedRows.filter(Boolean).length}/5 Hàng)</span>
              </div>
              <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden p-[1.5px] border border-slate-200/50">
                <div 
                  className="bg-gradient-to-r from-purple-500 to-indigo-500 h-full rounded-full transition-all duration-300 shadow-[0_0_8px_rgba(124,58,237,0.2)]"
                  style={{ width: `${finishedProgressPercentage}%` }}
                />
              </div>
            </div>

            {/* Active Question Bubble */}
            <div id="question_bubble" className="bg-white border-l-4 border-l-purple-600 border-y border-r border-purple-100 rounded-r-2xl rounded-l-lg p-3.5 shadow-xs shrink-0 transition-all">
              <div className="flex items-start gap-2.5">
                <div className="w-7 h-7 rounded-full bg-purple-600 text-white flex items-center justify-center shrink-0 font-extrabold text-[11px]">
                  {QUESTIONS[activeRowIndex].id}
                </div>
                <div className="flex-1 min-w-0">
                  <span className="text-[9px] uppercase tracking-wider text-purple-600 font-black">CÂU HỎI {QUESTIONS[activeRowIndex].id}</span>
                  <p className="text-[13px] font-bold text-slate-700 mt-0.5 leading-relaxed">
                    {QUESTIONS[activeRowIndex].question}
                  </p>
                </div>
              </div>
            </div>

            {/* Word Crossword Grid Block */}
            <div id="crossword_grid" className="flex-1 flex flex-col justify-center gap-2 pt-1 pb-1">
              {QUESTIONS.map((row, rIdx) => {
                const isActive = rIdx === activeRowIndex;
                const isCorrect = completedRows[rIdx];
                const isShaking = shakingRows[rIdx];

                return (
                  <div
                    key={row.id}
                    id={`word_row_${row.id}`}
                    onClick={() => selectRow(rIdx)}
                    className={`flex items-center justify-between p-2 rounded-xl border transition-all duration-300 cursor-pointer ${
                      isActive 
                        ? 'bg-purple-50/70 border-purple-400 shadow-[0_4px_16px_rgba(124,58,237,0.08)]' 
                        : isCorrect 
                          ? 'bg-emerald-50/70 border-emerald-300 hover:bg-emerald-50' 
                          : 'bg-white border-slate-200/60 hover:bg-slate-50/50'
                    } ${isShaking ? 'animate-shake border-red-400 shadow-[0_4px_12px_rgba(239,68,68,0.1)]' : ''}`}
                  >
                    {/* Row Index Indicator / State badge */}
                    <div className="flex items-center gap-1.5 shrink-0 pr-1">
                      <span className={`text-[10px] font-black w-5 h-5 rounded-md flex items-center justify-center ${
                        isCorrect 
                          ? 'bg-emerald-500 text-white shadow-sm' 
                          : isActive 
                            ? 'bg-purple-600 text-white shadow-sm' 
                            : 'bg-slate-100 text-slate-500 border border-slate-200'
                      }`}>
                        {row.id}
                      </span>
                    </div>

                    {/* Word characters blocks */}
                    <div className="flex-1 flex items-center justify-center gap-1 overflow-x-auto py-0.5 px-1 scrollbar-none">
                      {row.blocks.map((block, bIdx) => (
                        <div key={bIdx} className="flex items-center gap-1">
                          {Array.from({ length: block.length }).map((_, i) => {
                            const index = block.startIndex + i;
                            const isHint = row.hintIndices.includes(index);
                            const userValue = userAnswers[rIdx]?.[index] || '';
                            const isCellFocused = isActive && activeCellIndex === index;

                            return (
                              <div
                                key={index}
                                id={`cell_${row.id}_${index}`}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (gameState === 'PLAYING') {
                                    setActiveRowIndex(rIdx);
                                    setActiveCellIndex(index);
                                  }
                                }}
                                className={`w-8 h-9.5 sm:w-9.5 sm:h-11 text-[13px] font-extrabold flex items-center justify-center rounded-lg border uppercase transition-all duration-150 select-none ${
                                  isCorrect
                                    ? 'bg-emerald-500 text-white border-emerald-600 shadow-sm'
                                    : isHint
                                      ? 'bg-slate-100/90 border-slate-200 text-slate-400 cursor-not-allowed font-medium shadow-inner'
                                      : isCellFocused
                                        ? 'bg-purple-50 border-purple-600 text-purple-700 shadow-[0_0_10px_rgba(124,58,237,0.25)] animate-cell-pulse scale-105'
                                        : 'bg-white border-slate-300 text-slate-800 hover:border-purple-300 shadow-xs'
                                }`}
                              >
                                {userValue}
                              </div>
                            );
                          })}
                          {/* Spacing dot for word boundaries */}
                          {bIdx < row.blocks.length - 1 && (
                            <span className="w-1.5 h-1.5 rounded-full bg-slate-300/80 mx-0.5" />
                          )}
                        </div>
                      ))}
                    </div>

                    {/* Right Row Status Indicator Badge */}
                    <div className="w-8 shrink-0 flex items-center justify-end pl-1">
                      {isCorrect ? (
                        <div className="w-5.5 h-5.5 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center border border-emerald-300">
                          <Check size={12} className="stroke-[3]" />
                        </div>
                      ) : isActive ? (
                        <div className="text-[8px] font-black tracking-tighter bg-purple-600 text-white px-1.5 py-0.5 rounded uppercase shrink-0 shadow-sm">
                          Nhập
                        </div>
                      ) : (
                        <div className="w-1.5 h-1.5 rounded-full bg-slate-300 mx-auto" />
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Quick Helper Feedback Message Banner */}
            {message.text && (
              <div 
                id="message_toast" 
                className={`px-3 py-2 rounded-xl text-xs font-semibold text-center mt-auto shrink-0 flex items-center justify-center gap-1.5 transition-all ${
                  message.type === 'success' 
                    ? 'bg-emerald-50 border border-emerald-200 text-emerald-700 shadow-xs' 
                    : message.type === 'error' 
                      ? 'bg-red-50 border border-red-200 text-red-600 shadow-xs animate-shake' 
                      : 'bg-white border border-slate-100 text-slate-500 shadow-xs'
                }`}
              >
                {message.type === 'success' && <Check size={13} className="text-emerald-600 stroke-[3]" />}
                {message.type === 'error' && <HelpCircle size={13} className="text-red-500" />}
                <span>{message.text}</span>
              </div>
            )}

            {/* Action Buttons Toolbar */}
            <div className="grid grid-cols-2 gap-2.5 mt-1 shrink-0">
              <button
                id="reset_playing_btn"
                onClick={() => { handleStartGame(); }}
                className="py-3 px-4 rounded-xl text-slate-600 border border-slate-200/80 hover:bg-slate-50 bg-white text-xs font-bold tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-all shadow-xs"
              >
                <RotateCcw size={14} />
                <span>CHƠI LẠI</span>
              </button>

              <button
                id="check_answer_btn"
                onClick={handleCheckRowAnswers}
                className="py-3 px-4 rounded-xl bg-purple-600 text-white text-xs font-black tracking-wider flex items-center justify-center gap-2 hover:bg-purple-500 active:scale-95 shadow-[0_4px_14px_rgba(124,58,237,0.25)] transition-all"
              >
                <Check size={14} className="stroke-[3]" />
                <span>KIỂM TRA ĐÁP ÁN</span>
              </button>
            </div>

          </div>
        )}

        {/* Won State with glorious Confetti overlay */}
        {gameState === 'WON' && (
          <div id="screen_won" className="flex-grow flex flex-col justify-center items-center text-center py-6 relative">
            <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none w-full h-full z-10" />

            <div className="z-20 relative flex flex-col items-center max-w-sm px-4">
              
              {/* Star trophy medal */}
              <div className="relative mb-5">
                <div className="absolute inset-0 bg-yellow-300/30 blur-xl rounded-full scale-110" />
                <div className="w-20 h-20 bg-gradient-to-tr from-amber-400 to-yellow-300 text-slate-950 rounded-full flex items-center justify-center border-2 border-white shadow-md animate-bounce">
                  <Trophy size={40} className="stroke-[1.5]" />
                </div>
              </div>

              <div className="text-[10px] font-black tracking-widest text-purple-700 bg-purple-100/80 border border-purple-200/50 px-3 py-1 rounded-full uppercase mb-2.5 shadow-2xs">
                Hoàn thành xuất sắc!
              </div>

              <h2 className="text-3xl font-black text-slate-800 uppercase tracking-tight leading-tight">
                BUDDY MASTER!
              </h2>
              
              <p className="text-[14px] font-extrabold text-purple-700 mt-2 bg-purple-50 border border-purple-100 px-4 py-1.5 rounded-full inline-block">
                “Bạn đã trở thành Buddy Master!”
              </p>

              {/* Stats Box */}
              <div className="w-full max-w-xs bg-white border border-purple-100 rounded-2xl p-4 mt-6 mb-7 grid grid-cols-2 gap-3.5 divide-x divide-slate-100 shadow-[0_8px_30px_rgba(124,58,237,0.06)]">
                <div className="text-center">
                  <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Tổng thời gian</div>
                  <div className="text-lg font-black text-slate-800 font-mono mt-1">{formatTime(timer)}</div>
                </div>
                <div className="text-center pl-3.5">
                  <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Tổng điểm số</div>
                  <div className="text-lg font-black text-purple-600 font-mono mt-1">{score}</div>
                </div>
              </div>

              {bestTime !== null && bestTime === timer && (
                <div className="bg-amber-100/70 border border-amber-300 text-amber-800 text-[11px] font-extrabold px-3.5 py-2 rounded-xl mb-6 flex items-center justify-center gap-1.5 animate-pulse">
                  <Star size={13} className="fill-current text-amber-600" />
                  KỶ LỤC MỚI CỦA BẠN!
                </div>
              )}

              <button
                id="play_again_btn"
                onClick={handleStartGame}
                className="w-full max-w-xs bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-4 rounded-xl font-extrabold tracking-wider flex items-center justify-center gap-2 shadow-[0_6px_22px_rgba(124,58,237,0.3)] hover:from-purple-500 hover:to-indigo-500 active:scale-95 transition-all"
              >
                <RotateCcw size={15} />
                <span>CHƠI LẠI TRẬN MỚI</span>
              </button>
            </div>
          </div>
        )}

      </main>

      {/* Styled On-Screen Keyboard */}
      {gameState === 'PLAYING' && (
        <footer className="bg-slate-100/90 backdrop-blur-md border-t border-slate-200/60 p-3 pt-2 shrink-0 z-10 select-none shadow-[0_-4px_20px_rgba(0,0,0,0.02)]">
          <div className="max-w-md mx-auto flex flex-col gap-1.5">
            {KEYBOARD_LAYOUT.map((row, rowIdx) => (
              <div key={rowIdx} className="flex justify-center gap-1">
                {row.map((key) => {
                  const isSpecialKey = key === 'Backspace' || key === 'Check';
                  
                  return (
                    <button
                      id={`virtual_key_${key.toLowerCase()}`}
                      key={key}
                      onClick={() => {
                        if (key === 'Backspace') {
                          handleBackspace();
                        } else if (key === 'Check') {
                          handleCheckRowAnswers();
                        } else {
                          handleKeyInput(key);
                        }
                      }}
                      className={`text-[11px] font-extrabold h-11 flex-1 flex items-center justify-center rounded-lg active:scale-90 transition-all ${
                        isSpecialKey
                          ? key === 'Check'
                            ? 'bg-purple-600 text-white font-heavy px-2 text-[10px] uppercase tracking-wider shadow-sm'
                            : 'bg-slate-200 text-slate-700 font-heavy px-2 text-[10px] uppercase tracking-wider'
                          : 'bg-white text-slate-800 hover:bg-slate-50 border border-slate-200 shadow-2xs active:bg-slate-100'
                      }`}
                    >
                      {key === 'Backspace' ? '⌫' : key === 'Check' ? 'Check' : key}
                    </button>
                  );
                })}
              </div>
            ))}
          </div>
        </footer>
      )}
    </div>
  );
}
